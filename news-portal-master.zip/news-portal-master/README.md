# news-portal

Project portal of news.

Objective, to develop a simple news portal, using node js, framework express among other modules and middleware, such as EJS, Express-validator, consign. 
Design pattern MVC.

obs: In the TEMPLATE branch the project is joined by template and bakend.
